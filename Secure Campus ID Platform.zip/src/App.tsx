import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BedDouble,
  Bell,
  BookOpen,
  Bus,
  Camera,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  CreditCard,
  DoorOpen,
  Eye,
  EyeOff,
  Fingerprint,
  GraduationCap,
  History,
  LayoutDashboard,
  LockKeyhole,
  LogOut,
  Menu,
  MoreHorizontal,
  ParkingCircle,
  PencilLine,
  Plus,
  QrCode,
  RefreshCw,
  ScanLine,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  UserCheck,
  UserRound,
  UtensilsCrossed,
  X,
  XCircle,
  Zap,
} from "lucide-react";

type Page = "landing" | "login" | "id" | "activity" | "verifier" | "admin";
type Role = "Student" | "Staff" | "Admin";
type IconType = typeof DoorOpen;
type Service = {
  name: string;
  description: string;
  icon: IconType;
  color: string;
  tint: string;
  fields: string[];
};

const services: Service[] = [
  {
    name: "Campus Gate",
    description: "Fast, secure entry and exit",
    icon: DoorOpen,
    color: "#2563eb",
    tint: "#eff6ff",
    fields: ["Student status", "Full name", "Direction"],
  },
  {
    name: "Library",
    description: "Borrow and access resources",
    icon: BookOpen,
    color: "#7c3aed",
    tint: "#f5f3ff",
    fields: ["Student status"],
  },
  {
    name: "Hostel",
    description: "Resident access and curfew logs",
    icon: BedDouble,
    color: "#0891b2",
    tint: "#ecfeff",
    fields: ["Student status", "Resident status", "Entry time"],
  },
  {
    name: "Exam Hall",
    description: "Identity-safe exam check-in",
    icon: PencilLine,
    color: "#ea580c",
    tint: "#fff7ed",
    fields: ["Student status", "Full name", "Roll number", "Photo"],
  },
  {
    name: "Canteen",
    description: "Meal plan and balance checks",
    icon: UtensilsCrossed,
    color: "#16a34a",
    tint: "#f0fdf4",
    fields: ["Student status", "Meal plan", "Balance"],
  },
];

const activityRows = [
  {
    service: "Library",
    detail: "Identity verified",
    time: "Today, 10:32 AM",
    icon: BookOpen,
    color: "#7c3aed",
    tint: "#f5f3ff",
  },
  {
    service: "Campus Gate",
    detail: "Entry logged",
    time: "Today, 8:46 AM",
    icon: DoorOpen,
    color: "#2563eb",
    tint: "#eff6ff",
  },
  {
    service: "Canteen",
    detail: "Meal pass verified",
    time: "Yesterday, 1:14 PM",
    icon: UtensilsCrossed,
    color: "#16a34a",
    tint: "#f0fdf4",
  },
  {
    service: "Hostel",
    detail: "Entry logged",
    time: "Yesterday, 9:18 PM",
    icon: BedDouble,
    color: "#0891b2",
    tint: "#ecfeff",
  },
  {
    service: "Exam Hall",
    detail: "Identity verified",
    time: "May 20, 9:02 AM",
    icon: PencilLine,
    color: "#ea580c",
    tint: "#fff7ed",
  },
];

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="logo" aria-label="UniKey home">
      <span className="logo-mark">
        <ShieldCheck size={22} strokeWidth={2.5} />
      </span>
      {!compact && (
        <span className="logo-word">
          Uni<span>Key</span>
        </span>
      )}
    </div>
  );
}

function IconBubble({
  icon: Icon,
  color,
  tint,
  size = 44,
}: {
  icon: IconType;
  color: string;
  tint: string;
  size?: number;
}) {
  return (
    <span className="icon-bubble" style={{ color, background: tint, width: size, height: size }}>
      <Icon size={size * 0.46} strokeWidth={2} />
    </span>
  );
}

function Landing({ navigate }: { navigate: (page: Page) => void }) {
  return (
    <div className="landing">
      <header className="public-nav">
        <Logo />
        <nav className="nav-links">
          <a href="#how">How it works</a>
          <a href="#services">Services</a>
          <a href="#security">Security</a>
        </nav>
        <div className="nav-actions">
          <button className="text-button" onClick={() => navigate("login")}>
            Sign in
          </button>
          <button className="primary-button compact" onClick={() => navigate("login")}>
            Get started <ArrowRight size={16} />
          </button>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-glow one" />
          <div className="hero-glow two" />
          <div className="hero-copy">
            <div className="eyebrow">
              <Sparkles size={15} /> The privacy-first campus identity
            </div>
            <h1>
              One ID. Every campus service. <span>Secure by design.</span>
            </h1>
            <p>
              Move through campus with one trusted digital identity that shares only what each
              service needs—and nothing more.
            </p>
            <div className="hero-actions">
              <button className="primary-button large" onClick={() => navigate("login")}>
                Open your digital ID <ArrowRight size={18} />
              </button>
              <button className="secondary-button large" onClick={() => navigate("verifier")}>
                <ScanLine size={18} /> Try verifier demo
              </button>
            </div>
            <div className="trust-line">
              <span>
                <CheckCircle2 size={17} /> 30-second credentials
              </span>
              <span>
                <CheckCircle2 size={17} /> Minimal disclosure
              </span>
              <span>
                <CheckCircle2 size={17} /> Full access history
              </span>
            </div>
          </div>
          <div className="hero-visual" aria-label="Digital student identity preview">
            <div className="float-card float-security">
              <span>
                <ShieldCheck size={18} />
              </span>
              <div>
                <b>Identity protected</b>
                <small>2-factor authentication on</small>
              </div>
            </div>
            <div className="mini-id">
              <div className="mini-card-top">
                <Logo />
                <span className="verified-pill">
                  <Check size={13} /> Verified
                </span>
              </div>
              <div className="mini-student">
                <div className="avatar avatar-lg">AS</div>
                <div>
                  <small>STUDENT IDENTITY</small>
                  <h3>Aarav Sharma</h3>
                  <p>B.Tech · Computer Science</p>
                </div>
              </div>
              <div className="mini-qr-row">
                <div className="qr-wrap small">
                  <QRCodeSVG value="unikey-demo-student-identity-token" size={106} level="M" />
                </div>
                <div>
                  <span className="live-dot" /> LIVE CREDENTIAL<strong>00:24</strong>
                  <small>Refreshes automatically</small>
                </div>
              </div>
            </div>
            <div className="float-card float-access">
              <IconBubble icon={BookOpen} color="#7c3aed" tint="#f5f3ff" size={38} />
              <div>
                <b>Library verified</b>
                <small>Only status was shared</small>
              </div>
              <CheckCircle2 size={20} color="#16a34a" />
            </div>
          </div>
        </section>

        <section className="section" id="how">
          <div className="section-heading">
            <span>HOW IT WORKS</span>
            <h2>Your campus, unlocked in three steps</h2>
            <p>Built to be effortless for students and trustworthy for every service.</p>
          </div>
          <div className="steps-grid">
            {[
              {
                n: "01",
                icon: Fingerprint,
                title: "Secure your identity",
                text: "Sign in with your campus credentials and a second factor only you control.",
              },
              {
                n: "02",
                icon: QrCode,
                title: "Show your dynamic ID",
                text: "Your QR credential refreshes every 30 seconds and contains no personal data.",
              },
              {
                n: "03",
                icon: UserCheck,
                title: "Share only what’s needed",
                text: "Each service sees only the minimum information it is permitted to access.",
              },
            ].map((step) => (
              <article className="step-card" key={step.n}>
                <span className="step-number">{step.n}</span>
                <IconBubble icon={step.icon} color="#1e3a8a" tint="#eff6ff" size={54} />
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="section services-section" id="services">
          <div className="section-heading left">
            <span>ONE ID, EVERYWHERE</span>
            <h2>Made for the way campus moves</h2>
            <p>
              From your first entry to your last meal, UniKey makes every check instant and private.
            </p>
          </div>
          <div className="service-grid">
            {services.map(({ name, description, icon, color, tint }) => (
              <article className="service-card" key={name}>
                <IconBubble icon={icon} color={color} tint={tint} size={48} />
                <h3>{name}</h3>
                <p>{description}</p>
                <span className="learn-link">
                  Learn more <ArrowRight size={15} />
                </span>
              </article>
            ))}
          </div>
        </section>

        <section className="security-section" id="security">
          <div className="security-copy">
            <span className="light-eyebrow">
              <ShieldCheck size={16} /> SECURITY BY DEFAULT
            </span>
            <h2>Your identity stays yours.</h2>
            <p>
              UniKey is designed around a simple principle: prove what’s needed without revealing
              everything.
            </p>
            <div className="security-list">
              {[
                [
                  "Nothing sensitive in your QR",
                  "The code contains only a short-lived, anonymous reference.",
                ],
                ["Every access is visible", "See exactly which service checked your ID and when."],
                ["One scan. One use.", "Replay protection makes copied credentials useless."],
              ].map(([title, text]) => (
                <div key={title}>
                  <CheckCircle2 size={21} />
                  <span>
                    <b>{title}</b>
                    <small>{text}</small>
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div className="security-panel">
            <div className="security-orbit">
              <ShieldCheck size={50} />
              <span className="orbit-dot d1">
                <LockKeyhole size={16} />
              </span>
              <span className="orbit-dot d2">
                <Fingerprint size={17} />
              </span>
              <span className="orbit-dot d3">
                <EyeOff size={17} />
              </span>
            </div>
            <div className="encrypted-chip">
              <span className="pulse-dot" /> All credentials encrypted
            </div>
          </div>
        </section>
      </main>
      <footer>
        <Logo />
        <p>Secure campus identity, made simple.</p>
        <span>Prototype · Dummy data only</span>
      </footer>
    </div>
  );
}

function Login({
  navigate,
  onAuthenticated,
}: {
  navigate: (page: Page) => void;
  onAuthenticated: (role: Role) => void;
}) {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [step, setStep] = useState<"credentials" | "mfa">("credentials");
  const [role, setRole] = useState<Role>("Student");
  const [showPassword, setShowPassword] = useState(false);
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);

  function submitCredentials(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    window.setTimeout(() => {
      setLoading(false);
      setStep("mfa");
    }, 650);
  }

  function verify(e: FormEvent) {
    e.preventDefault();
    if (otp.length !== 6) return;
    setLoading(true);
    window.setTimeout(() => {
      setLoading(false);
      onAuthenticated(role);
    }, 650);
  }

  return (
    <div className="auth-page">
      <button className="back-link" onClick={() => navigate("landing")}>
        <ArrowLeft size={18} /> Back to home
      </button>
      <div className="auth-aside">
        <Logo />
        <div className="aside-copy">
          <span className="light-eyebrow">
            <ShieldCheck size={15} /> CAMPUS IDENTITY, REIMAGINED
          </span>
          <h1>
            Access your campus.
            <br />
            Not your privacy.
          </h1>
          <p>
            One secure identity for every service, protected by strong authentication and minimal
            data sharing.
          </p>
        </div>
        <div className="aside-proof">
          <div className="proof-avatars">
            <span>AS</span>
            <span>NK</span>
            <span>RP</span>
          </div>
          <div>
            <b>Trusted across campus</b>
            <small>12,000+ students protected</small>
          </div>
        </div>
      </div>
      <div className="auth-main">
        <div className="auth-card">
          <div className="mobile-auth-logo">
            <Logo />
          </div>
          {step === "credentials" ? (
            <>
              <div className="auth-heading">
                <span className="auth-icon">
                  <LockKeyhole size={23} />
                </span>
                <h2>{mode === "signin" ? "Welcome back" : "Create your account"}</h2>
                <p>
                  {mode === "signin"
                    ? "Sign in to access your secure campus identity."
                    : "Set up your secure campus identity in minutes."}
                </p>
              </div>
              <div className="auth-tabs">
                <button
                  className={mode === "signin" ? "active" : ""}
                  onClick={() => setMode("signin")}
                >
                  Sign in
                </button>
                <button
                  className={mode === "signup" ? "active" : ""}
                  onClick={() => setMode("signup")}
                >
                  Sign up
                </button>
              </div>
              <form onSubmit={submitCredentials}>
                {mode === "signup" && (
                  <label>
                    Full name
                    <input required defaultValue="Aarav Sharma" />
                  </label>
                )}
                <label>
                  Institutional email
                  <input
                    type="email"
                    required
                    defaultValue={
                      role === "Student"
                        ? "aarav.sharma@northstar.edu"
                        : role === "Staff"
                          ? "verifier@northstar.edu"
                          : "admin@northstar.edu"
                    }
                  />
                </label>
                <label>
                  Password
                  <span className="password-field">
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      defaultValue="securepass123"
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)}>
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </span>
                </label>
                <div className="form-row">
                  <label className="check-row">
                    <input type="checkbox" defaultChecked /> Remember me
                  </label>
                  <button type="button" className="link-button">
                    Forgot password?
                  </button>
                </div>
                <label>
                  Demo role
                  <span className="select-field">
                    <select value={role} onChange={(e) => setRole(e.target.value as Role)}>
                      <option>Student</option>
                      <option>Staff</option>
                      <option>Admin</option>
                    </select>
                    <ChevronDown size={17} />
                  </span>
                </label>
                <button className="primary-button auth-submit" disabled={loading}>
                  {loading ? (
                    <>
                      <RefreshCw className="spin" size={18} /> Checking…
                    </>
                  ) : (
                    <>
                      {mode === "signin" ? "Continue securely" : "Create secure account"}{" "}
                      <ArrowRight size={18} />
                    </>
                  )}
                </button>
              </form>
              <div className="auth-note">
                <ShieldCheck size={16} /> Protected with rate limiting and bcrypt-secured
                credentials
              </div>
            </>
          ) : (
            <form onSubmit={verify} className="mfa-form">
              <button type="button" className="mfa-back" onClick={() => setStep("credentials")}>
                <ArrowLeft size={17} /> Back
              </button>
              <div className="auth-heading">
                <span className="auth-icon">
                  <Fingerprint size={24} />
                </span>
                <h2>Verify it’s you</h2>
                <p>Enter the 6-digit code from your authenticator app.</p>
              </div>
              {mode === "signup" && (
                <div className="setup-qr">
                  <QRCodeSVG
                    value="otpauth://totp/UniKey:aarav.sharma@northstar.edu?secret=JBSWY3DPEHPK3PXP&issuer=UniKey"
                    size={116}
                  />
                  <div>
                    <b>Scan to set up 2FA</b>
                    <small>Use Google Authenticator or any compatible app.</small>
                    <code>JBSW Y3DP EHPK 3PXP</code>
                  </div>
                </div>
              )}
              <div
                className="otp-inputs"
                onClick={() => document.getElementById("otp-real")?.focus()}
              >
                {[0, 1, 2, 3, 4, 5].map((i) => (
                  <span className={otp[i] ? "filled" : ""} key={i}>
                    {otp[i] || ""}
                  </span>
                ))}
                <input
                  id="otp-real"
                  autoFocus
                  inputMode="numeric"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                />
              </div>
              <p className="demo-hint">Demo: enter any 6 digits</p>
              <button className="primary-button auth-submit" disabled={otp.length !== 6 || loading}>
                {loading ? (
                  <>
                    <RefreshCw className="spin" size={18} /> Verifying…
                  </>
                ) : (
                  <>
                    Verify & sign in <ArrowRight size={18} />
                  </>
                )}
              </button>
              <button type="button" className="link-button center">
                Can’t access your authenticator?
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

function StudentShell({
  page,
  navigate,
  children,
}: {
  page: Page;
  navigate: (p: Page) => void;
  children: ReactNode;
}) {
  return (
    <div className="app-shell">
      <aside className="app-sidebar">
        <Logo />
        <div className="student-mini">
          <div className="avatar">AS</div>
          <div>
            <b>Aarav Sharma</b>
            <small>Student</small>
          </div>
        </div>
        <nav>
          <button className={page === "id" ? "active" : ""} onClick={() => navigate("id")}>
            <CreditCard size={19} /> My digital ID
          </button>
          <button
            className={page === "activity" ? "active" : ""}
            onClick={() => navigate("activity")}
          >
            <History size={19} /> Activity
          </button>
          <button>
            <ShieldCheck size={19} /> Privacy & consent
          </button>
          <button>
            <Settings size={19} /> Settings
          </button>
        </nav>
        <button className="logout-button" onClick={() => navigate("landing")}>
          <LogOut size={18} /> Sign out
        </button>
      </aside>
      <div className="app-content">
        <header className="app-topbar">
          <div className="mobile-logo">
            <Logo />
          </div>
          <div className="topbar-title">
            <b>{page === "id" ? "My digital ID" : "Activity"}</b>
            <small>Northstar University</small>
          </div>
          <div className="topbar-actions">
            <button className="icon-button">
              <Bell size={19} />
              <span />
            </button>
            <div className="avatar small">AS</div>
          </div>
        </header>
        {children}
        <nav className="mobile-bottom-nav">
          <button className={page === "id" ? "active" : ""} onClick={() => navigate("id")}>
            <CreditCard size={21} />
            <span>My ID</span>
          </button>
          <button
            className={page === "activity" ? "active" : ""}
            onClick={() => navigate("activity")}
          >
            <History size={21} />
            <span>Activity</span>
          </button>
          <button>
            <ShieldCheck size={21} />
            <span>Privacy</span>
          </button>
          <button>
            <Settings size={21} />
            <span>Settings</span>
          </button>
        </nav>
      </div>
    </div>
  );
}

function StudentId({ navigate }: { navigate: (p: Page) => void }) {
  const [remaining, setRemaining] = useState(30);
  const [tokenVersion, setTokenVersion] = useState(1);
  useEffect(() => {
    const timer = window.setInterval(() => {
      setRemaining((current) => {
        if (current <= 1) {
          setTokenVersion((v) => v + 1);
          return 30;
        }
        return current - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);
  const token = useMemo(
    () =>
      `eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c3JfN2Y4MmEiLCJqdGkiOiJjcmVkXz${tokenVersion}IiwiZXhwIjo${Date.now() + 30_000}fQ.signature`,
    [tokenVersion],
  );

  return (
    <StudentShell page="id" navigate={navigate}>
      <main className="student-page">
        <div className="page-intro">
          <div>
            <span className="welcome-kicker">GOOD MORNING, AARAV</span>
            <h1>Your campus identity</h1>
            <p>Present this secure credential at any participating campus service.</p>
          </div>
          <span className="status-badge">
            <span /> ID active
          </span>
        </div>
        <div className="id-layout">
          <section className="digital-id">
            <div className="id-watermark">
              <ShieldCheck />
            </div>
            <div className="id-top">
              <Logo />
              <span className="verified-pill">
                <Check size={14} /> Verified
              </span>
            </div>
            <div className="id-person">
              <div className="photo-placeholder">
                <UserRound size={47} />
                <span className="online-dot" />
              </div>
              <div>
                <small>STUDENT</small>
                <h2>Aarav Sharma</h2>
                <p>B.Tech · Computer Science</p>
                <span>Enrolment no. NSU2024CS0187</span>
              </div>
            </div>
            <div className="id-divider" />
            <div className="id-credential">
              <div className="qr-card">
                <QRCodeSVG value={token} size={172} level="M" />
              </div>
              <div className="credential-copy">
                <span className="credential-live">
                  <span /> LIVE CREDENTIAL
                </span>
                <h3>00:{String(remaining).padStart(2, "0")}</h3>
                <div className="count-track">
                  <span style={{ width: `${(remaining / 30) * 100}%` }} />
                </div>
                <p>
                  <RefreshCw size={14} className={remaining < 3 ? "spin" : ""} /> Refreshes
                  automatically
                </p>
              </div>
            </div>
            <div className="id-footer">
              <ShieldCheck size={15} /> No personal data is stored in this QR code{" "}
              <span>UNIVERSITY IDENTITY</span>
            </div>
          </section>
          <aside className="id-side">
            <div className="info-card">
              <span className="info-icon">
                <Zap size={19} />
              </span>
              <div>
                <h3>Ready to scan</h3>
                <p>
                  Turn up your screen brightness and hold the QR steady in front of the scanner.
                </p>
              </div>
            </div>
            <div className="privacy-card">
              <div className="card-title-row">
                <h3>Privacy at a glance</h3>
                <ShieldCheck size={20} />
              </div>
              <p>Services only see what they need.</p>
              <div className="privacy-example">
                <IconBubble icon={BookOpen} color="#7c3aed" tint="#f5f3ff" size={42} />
                <div>
                  <b>At the Library</b>
                  <small>Shares: Valid student</small>
                </div>
                <CheckCircle2 size={18} />
              </div>
              <div className="privacy-example">
                <IconBubble icon={PencilLine} color="#ea580c" tint="#fff7ed" size={42} />
                <div>
                  <b>At the Exam Hall</b>
                  <small>Shares: Name, roll no. & photo</small>
                </div>
                <CheckCircle2 size={18} />
              </div>
              <button onClick={() => navigate("activity")}>
                View all access activity <ArrowRight size={16} />
              </button>
            </div>
            <div className="help-card">
              <span>Need help?</span>
              <p>Contact Campus IT Support</p>
              <ArrowRight size={17} />
            </div>
          </aside>
        </div>
      </main>
    </StudentShell>
  );
}

function StudentActivity({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <StudentShell page="activity" navigate={navigate}>
      <main className="student-page activity-page">
        <div className="page-intro">
          <div>
            <span className="welcome-kicker">YOUR PRIVACY, MADE VISIBLE</span>
            <h1>Verification activity</h1>
            <p>Every time a campus service checks your identity, it appears here.</p>
          </div>
          <button className="secondary-button">
            <ShieldCheck size={17} /> Manage consent
          </button>
        </div>
        <div className="activity-summary">
          <div>
            <IconBubble icon={CheckCircle2} color="#16a34a" tint="#f0fdf4" />
            <span>
              <b>12</b>
              <small>Verifications this month</small>
            </span>
          </div>
          <div>
            <IconBubble icon={EyeOff} color="#2563eb" tint="#eff6ff" />
            <span>
              <b>100%</b>
              <small>Minimal data shared</small>
            </span>
          </div>
          <div>
            <IconBubble icon={AlertTriangle} color="#f59e0b" tint="#fffbeb" />
            <span>
              <b>0</b>
              <small>Security alerts</small>
            </span>
          </div>
        </div>
        <section className="activity-card">
          <div className="activity-card-head">
            <div>
              <h2>Recent activity</h2>
              <p>Your latest identity checks across campus</p>
            </div>
            <button className="filter-button">
              Last 30 days <ChevronDown size={16} />
            </button>
          </div>
          <div className="timeline">
            {activityRows.map((row, i) => (
              <div className="timeline-row" key={`${row.service}${i}`}>
                <div className="timeline-line" />
                <IconBubble icon={row.icon} color={row.color} tint={row.tint} size={44} />
                <div className="timeline-copy">
                  <b>{row.service}</b>
                  <span>{row.detail}</span>
                  <small>{row.time}</small>
                </div>
                <span className="verified-result">
                  <Check size={14} /> Verified
                </span>
                <button className="more-button">
                  <MoreHorizontal size={20} />
                </button>
              </div>
            ))}
          </div>
        </section>
      </main>
    </StudentShell>
  );
}

function Verifier({ navigate }: { navigate: (p: Page) => void }) {
  const [selected, setSelected] = useState<Service>(services[0]);
  const [scanMode, setScanMode] = useState<"camera" | "paste">("camera");
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<"valid" | "invalid" | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const Icon = selected.icon;
  function verify(valid = true) {
    setScanning(true);
    setResult(null);
    window.setTimeout(() => {
      setScanning(false);
      setResult(valid ? "valid" : "invalid");
    }, 900);
  }
  return (
    <div className="verifier-page">
      <header className="verifier-topbar">
        <Logo />
        <div className="verifier-label">
          <span>STAFF VERIFIER</span>
          <small>Northstar University</small>
        </div>
        <div className="verifier-user">
          <span>
            <b>Maya Patel</b>
            <small>Service staff</small>
          </span>
          <div className="avatar small">MP</div>
          <button onClick={() => navigate("landing")}>
            <LogOut size={18} />
          </button>
        </div>
      </header>
      <main className="verifier-main">
        <div className="verifier-heading">
          <div>
            <span className="welcome-kicker">IDENTITY CHECK</span>
            <h1>Verify a student</h1>
            <p>Select your service, then scan the student’s live credential.</p>
          </div>
          <span className="secure-connection">
            <span /> Secure connection
          </span>
        </div>
        <div className="verifier-grid">
          <section>
            <label className="field-label">Verifying for</label>
            <div className="service-select-wrap">
              <button className="service-select" onClick={() => setMenuOpen(!menuOpen)}>
                <IconBubble
                  icon={selected.icon}
                  color={selected.color}
                  tint={selected.tint}
                  size={42}
                />
                <span>
                  <b>{selected.name}</b>
                  <small>{selected.description}</small>
                </span>
                <ChevronDown size={18} />
              </button>
              {menuOpen && (
                <div className="service-menu">
                  {services.map((s) => (
                    <button
                      key={s.name}
                      onClick={() => {
                        setSelected(s);
                        setMenuOpen(false);
                        setResult(null);
                      }}
                    >
                      <IconBubble icon={s.icon} color={s.color} tint={s.tint} size={37} />
                      <span>
                        <b>{s.name}</b>
                        <small>{s.fields.length} permitted fields</small>
                      </span>
                      {s.name === selected.name && <Check size={17} />}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="disclosure-note">
              <EyeOff size={18} />
              <div>
                <b>Minimal disclosure is on</b>
                <p>
                  {selected.name} can only view: {selected.fields.join(", ").toLowerCase()}.
                </p>
              </div>
            </div>
            <div className="scan-card">
              <div className="scan-tabs">
                <button
                  className={scanMode === "camera" ? "active" : ""}
                  onClick={() => setScanMode("camera")}
                >
                  <Camera size={17} /> Scan camera
                </button>
                <button
                  className={scanMode === "paste" ? "active" : ""}
                  onClick={() => setScanMode("paste")}
                >
                  <QrCode size={17} /> Paste token
                </button>
              </div>
              {scanMode === "camera" ? (
                <div className="camera-area">
                  <div className="scanner-corners">
                    <span />
                    <span />
                    <span />
                    <span />
                    {scanning && <i />}
                  </div>
                  <Camera size={35} />
                  <h3>{scanning ? "Reading credential…" : "Ready to scan"}</h3>
                  <p>Position the student’s QR code inside the frame</p>
                  <button
                    className="primary-button"
                    onClick={() => verify(true)}
                    disabled={scanning}
                  >
                    {scanning ? (
                      <>
                        <RefreshCw className="spin" size={17} /> Scanning…
                      </>
                    ) : (
                      <>
                        <ScanLine size={17} /> Start demo scan
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <form
                  className="paste-panel"
                  onSubmit={(e) => {
                    e.preventDefault();
                    verify(true);
                  }}
                >
                  <label>
                    Credential token
                    <textarea
                      required
                      placeholder="Paste the signed student credential here…"
                      defaultValue="eyJhbGciOiJIUzI1NiJ9.demo-token.signature"
                    />
                  </label>
                  <div className="paste-actions">
                    <button
                      type="button"
                      className="secondary-button"
                      onClick={() => verify(false)}
                    >
                      Test expired token
                    </button>
                    <button className="primary-button">
                      Verify token <ArrowRight size={17} />
                    </button>
                  </div>
                </form>
              )}
            </div>
          </section>
          <aside className={`result-card ${result || ""}`}>
            {!result && (
              <div className="empty-result">
                <span>
                  <ScanLine size={37} />
                </span>
                <h2>Waiting for a scan</h2>
                <p>
                  The verification result will appear here. Only permitted fields will be displayed.
                </p>
                <div className="empty-lock">
                  <LockKeyhole size={15} /> One-time credential verification
                </div>
              </div>
            )}
            {result === "valid" && (
              <ValidResult service={selected} onReset={() => setResult(null)} />
            )}
            {result === "invalid" && (
              <div className="invalid-result">
                <span className="result-icon">
                  <XCircle size={43} />
                </span>
                <small>VERIFICATION FAILED</small>
                <h2>Invalid / Expired</h2>
                <p>This credential has expired, was revoked, or has already been used.</p>
                <div className="warning-box">
                  <AlertTriangle size={19} />
                  <span>
                    <b>Do not grant access</b>
                    <small>Ask the student to refresh their digital ID and try again.</small>
                  </span>
                </div>
                <button className="secondary-button" onClick={() => setResult(null)}>
                  <RefreshCw size={17} /> Scan another credential
                </button>
              </div>
            )}
          </aside>
        </div>
      </main>
    </div>
  );
}

function ValidResult({ service, onReset }: { service: Service; onReset: () => void }) {
  const isExam = service.name === "Exam Hall";
  return (
    <div className="valid-result">
      <div className="result-success-head">
        <span className="result-icon">
          <Check size={42} />
        </span>
        <small>VERIFICATION SUCCESSFUL</small>
        <h2>Valid Student</h2>
        <p>Credential verified just now</p>
      </div>
      {isExam && (
        <div className="exam-profile">
          <div className="photo-placeholder small-photo">
            <UserRound size={32} />
          </div>
          <div>
            <b>Aarav Sharma</b>
            <span>NSU2024CS0187</span>
          </div>
        </div>
      )}
      <div className="disclosed-fields">
        <span>DISCLOSED TO {service.name.toUpperCase()}</span>
        <div>
          <b>Student status</b>
          <em>
            <Check size={14} /> Active
          </em>
        </div>
        {service.name === "Campus Gate" && (
          <>
            <div>
              <b>Full name</b>
              <strong>Aarav Sharma</strong>
            </div>
            <div>
              <b>Direction</b>
              <strong>Entry · 10:42 AM</strong>
            </div>
          </>
        )}
        {service.name === "Hostel" && (
          <>
            <div>
              <b>Hostel resident</b>
              <em>
                <Check size={14} /> Yes · Block C
              </em>
            </div>
            <div>
              <b>Entry time</b>
              <strong>10:42 AM</strong>
            </div>
          </>
        )}
        {service.name === "Canteen" && (
          <>
            <div>
              <b>Meal plan</b>
              <em>
                <Check size={14} /> Active
              </em>
            </div>
            <div>
              <b>Remaining balance</b>
              <strong>₹1,240</strong>
            </div>
          </>
        )}
        {isExam && (
          <>
            <div>
              <b>Full name</b>
              <strong>Aarav Sharma</strong>
            </div>
            <div>
              <b>Roll number</b>
              <strong>NSU2024CS0187</strong>
            </div>
          </>
        )}
      </div>
      <div className="single-use-note">
        <ShieldCheck size={17} /> This credential has now been consumed and cannot be reused.
      </div>
      <button className="primary-button" onClick={onReset}>
        <ScanLine size={17} /> Scan next student
      </button>
    </div>
  );
}

const adminLogs = [
  {
    student: "Aarav Sharma",
    id: "NSU2024CS0187",
    service: "Library",
    time: "10:32:18 AM",
    status: "Verified",
  },
  {
    student: "Nisha Kapoor",
    id: "NSU2023EC0094",
    service: "Campus Gate",
    time: "10:31:42 AM",
    status: "Verified",
  },
  {
    student: "Rohan Mehta",
    id: "NSU2024ME0142",
    service: "Hostel",
    time: "10:30:08 AM",
    status: "Late entry",
  },
  {
    student: "Ishita Verma",
    id: "NSU2022BA0087",
    service: "Exam Hall",
    time: "10:28:55 AM",
    status: "Verified",
  },
  {
    student: "Unknown credential",
    id: "Token expired",
    service: "Canteen",
    time: "10:27:31 AM",
    status: "Failed",
  },
];

function Admin({ navigate }: { navigate: (p: Page) => void }) {
  const [section, setSection] = useState("Overview");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [serviceList, setServiceList] = useState(services);
  const [addOpen, setAddOpen] = useState(false);
  const [students, setStudents] = useState([
    { name: "Aarav Sharma", id: "NSU2024CS0187", active: true },
    { name: "Nisha Kapoor", id: "NSU2023EC0094", active: true },
    { name: "Rohan Mehta", id: "NSU2024ME0142", active: false },
  ]);
  function addService(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    setServiceList([
      ...serviceList,
      {
        name: String(data.get("name")),
        description: "Custom campus service",
        icon: Bus,
        color: "#2563eb",
        tint: "#eff6ff",
        fields: ["Student status", "Full name"],
      },
    ]);
    setAddOpen(false);
  }
  return (
    <div className="admin-shell">
      <aside className={`admin-sidebar ${mobileMenu ? "open" : ""}`}>
        <div className="admin-brand">
          <Logo />
          <button className="close-menu" onClick={() => setMobileMenu(false)}>
            <X size={20} />
          </button>
        </div>
        <div className="admin-badge">ADMIN CONSOLE</div>
        <nav>
          {(
            [
              ["Overview", LayoutDashboard],
              ["Students", GraduationCap],
              ["Services", QrCode],
              ["Audit log", History],
              ["Alerts", AlertTriangle],
              ["Settings", Settings],
            ] as [string, IconType][]
          ).map(([name, ItemIcon]) => (
            <button
              key={name}
              className={section === name ? "active" : ""}
              onClick={() => {
                setSection(name);
                setMobileMenu(false);
              }}
            >
              <ItemIcon size={19} /> {name}
              {name === "Alerts" && <span className="nav-count">3</span>}
            </button>
          ))}
        </nav>
        <div className="admin-profile">
          <div className="avatar small">OP</div>
          <span>
            <b>Olivia Parker</b>
            <small>Security admin</small>
          </span>
          <button onClick={() => navigate("landing")}>
            <LogOut size={17} />
          </button>
        </div>
      </aside>
      <div className="admin-content">
        <header className="admin-topbar">
          <button className="menu-button" onClick={() => setMobileMenu(true)}>
            <Menu size={21} />
          </button>
          <div>
            <h1>{section}</h1>
            <p>Campus identity management and security</p>
          </div>
          <div className="admin-top-actions">
            <button className="icon-button">
              <Search size={19} />
            </button>
            <button className="icon-button">
              <Bell size={19} />
              <span />
            </button>
            <div className="avatar small">OP</div>
          </div>
        </header>
        {section === "Overview" && <AdminOverview setSection={setSection} />}
        {section === "Services" && (
          <ServicesAdmin services={serviceList} onAdd={() => setAddOpen(true)} />
        )}
        {section === "Students" && (
          <StudentsAdmin
            students={students}
            toggle={(id) =>
              setStudents(students.map((s) => (s.id === id ? { ...s, active: !s.active } : s)))
            }
          />
        )}
        {section !== "Overview" && section !== "Services" && section !== "Students" && (
          <PlaceholderAdmin section={section} />
        )}
      </div>
      {addOpen && (
        <div className="modal-backdrop">
          <form className="modal" onSubmit={addService}>
            <div className="modal-head">
              <div>
                <h2>Add campus service</h2>
                <p>Choose the minimum identity fields this service may access.</p>
              </div>
              <button type="button" onClick={() => setAddOpen(false)}>
                <X size={20} />
              </button>
            </div>
            <label>
              Service name
              <input name="name" required placeholder="e.g. Bus Pass" />
            </label>
            <label>
              Purpose
              <textarea placeholder="Explain why this service verifies students" />
            </label>
            <span className="field-label">Permitted fields</span>
            <div className="field-checks">
              {[
                "Student status",
                "Full name",
                "Roll number",
                "Photo",
                "Resident status",
                "Meal balance",
              ].map((field, i) => (
                <label key={field}>
                  <input type="checkbox" defaultChecked={i === 0} /> {field}
                </label>
              ))}
            </div>
            <div className="modal-actions">
              <button type="button" className="secondary-button" onClick={() => setAddOpen(false)}>
                Cancel
              </button>
              <button className="primary-button">Add service</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

function AdminOverview({ setSection }: { setSection: (s: string) => void }) {
  return (
    <main className="admin-page">
      <div className="admin-welcome">
        <div>
          <span>THURSDAY, MAY 22</span>
          <h2>Good morning, Olivia</h2>
          <p>Here’s what’s happening across campus identity today.</p>
        </div>
        <button className="primary-button" onClick={() => setSection("Students")}>
          <UserCheck size={17} /> Manage students
        </button>
      </div>
      <div className="stat-grid">
        {[
          ["Total students", "12,482", "+148 this semester", GraduationCap, "#2563eb", "#eff6ff"],
          ["Active IDs", "12,294", "98.5% of students", ShieldCheck, "#16a34a", "#f0fdf4"],
          ["Revoked IDs", "188", "12 restored this month", LockKeyhole, "#64748b", "#f1f5f9"],
          ["Alerts today", "3", "1 requires attention", AlertTriangle, "#f59e0b", "#fffbeb"],
        ].map(([label, value, meta, StatIcon, color, tint]) => (
          <div className="stat-card" key={label as string}>
            <div>
              <span>{label as string}</span>
              <b>{value as string}</b>
              <small>{meta as string}</small>
            </div>
            <IconBubble
              icon={StatIcon as IconType}
              color={color as string}
              tint={tint as string}
              size={46}
            />
          </div>
        ))}
      </div>
      <div className="admin-two-col">
        <section className="dashboard-card alert-panel">
          <div className="dashboard-card-head">
            <div>
              <h3>Security alerts</h3>
              <p>Events that may need your attention</p>
            </div>
            <button onClick={() => setSection("Alerts")}>
              View all <ArrowRight size={15} />
            </button>
          </div>
          <div className="alert-row high">
            <span>
              <AlertTriangle size={19} />
            </span>
            <div>
              <b>Rapid cross-service verification</b>
              <p>Same ID used at Library and Gate within 42 seconds</p>
              <small>2 minutes ago · Aarav Sharma</small>
            </div>
            <em>HIGH</em>
          </div>
          <div className="alert-row medium">
            <span>
              <Clock3 size={19} />
            </span>
            <div>
              <b>Hostel entry after curfew</b>
              <p>Student entry logged at 11:48 PM</p>
              <small>Last night · Rohan Mehta</small>
            </div>
            <em>MEDIUM</em>
          </div>
          <div className="alert-row medium">
            <span>
              <XCircle size={19} />
            </span>
            <div>
              <b>Repeated failed scans</b>
              <p>5 expired credentials from Canteen terminal</p>
              <small>Yesterday · Terminal CN-04</small>
            </div>
            <em>MEDIUM</em>
          </div>
        </section>
        <section className="dashboard-card traffic-panel">
          <div className="dashboard-card-head">
            <div>
              <h3>Verification traffic</h3>
              <p>Last 7 days</p>
            </div>
            <button className="filter-button">
              All services <ChevronDown size={14} />
            </button>
          </div>
          <div className="chart">
            {[38, 53, 46, 72, 61, 83, 68].map((v, i) => (
              <div key={i}>
                <span style={{ height: `${v}%` }} />
                <small>{["Fri", "Sat", "Sun", "Mon", "Tue", "Wed", "Thu"][i]}</small>
              </div>
            ))}
          </div>
          <div className="chart-total">
            <b>8,429</b>
            <span>Total verifications</span>
            <em>+12.4% vs last week</em>
          </div>
        </section>
      </div>
      <section className="dashboard-card log-card">
        <div className="dashboard-card-head">
          <div>
            <h3>Recent verification log</h3>
            <p>Live activity across all campus services</p>
          </div>
          <button onClick={() => setSection("Audit log")}>
            View full audit log <ArrowRight size={15} />
          </button>
        </div>
        <LogTable />
      </section>
    </main>
  );
}

function LogTable() {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Student</th>
            <th>Service</th>
            <th>Time</th>
            <th>Result</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {adminLogs.map((log) => (
            <tr key={log.time}>
              <td>
                <div className="table-student">
                  <div className="avatar tiny">
                    {log.student === "Unknown credential"
                      ? "?"
                      : log.student
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                  </div>
                  <span>
                    <b>{log.student}</b>
                    <small>{log.id}</small>
                  </span>
                </div>
              </td>
              <td>{log.service}</td>
              <td>{log.time}</td>
              <td>
                <span className={`table-status ${log.status.toLowerCase().replace(" ", "-")}`}>
                  {log.status === "Verified" && <Check size={13} />}
                  {log.status}
                </span>
              </td>
              <td>
                <MoreHorizontal size={18} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ServicesAdmin({ services, onAdd }: { services: Service[]; onAdd: () => void }) {
  return (
    <main className="admin-page">
      <div className="admin-welcome">
        <div>
          <span>MINIMAL DISCLOSURE</span>
          <h2>Campus services</h2>
          <p>Control which identity fields each service is permitted to view.</p>
        </div>
        <button className="primary-button" onClick={onAdd}>
          <Plus size={17} /> Add service
        </button>
      </div>
      <div className="managed-services">
        {services.map((s) => (
          <article key={s.name}>
            <div className="managed-service-head">
              <IconBubble icon={s.icon} color={s.color} tint={s.tint} size={48} />
              <span className="active-chip">
                <span /> Active
              </span>
              <button>
                <MoreHorizontal size={19} />
              </button>
            </div>
            <h3>{s.name}</h3>
            <p>{s.description}</p>
            <span className="field-label">PERMITTED FIELDS</span>
            <div className="field-tags">
              {s.fields.map((f) => (
                <span key={f}>{f}</span>
              ))}
            </div>
            <button className="edit-service">
              <Settings size={15} /> Configure access
            </button>
          </article>
        ))}
      </div>
    </main>
  );
}

function StudentsAdmin({
  students,
  toggle,
}: {
  students: { name: string; id: string; active: boolean }[];
  toggle: (id: string) => void;
}) {
  return (
    <main className="admin-page">
      <div className="admin-welcome">
        <div>
          <span>IDENTITY DIRECTORY</span>
          <h2>Student identities</h2>
          <p>Review identity status and immediately revoke or restore access.</p>
        </div>
        <button className="primary-button">
          <Plus size={17} /> Add student
        </button>
      </div>
      <section className="dashboard-card students-card">
        <div className="student-search">
          <Search size={18} />
          <input placeholder="Search by name or enrolment number…" />
          <button className="filter-button">
            All statuses <ChevronDown size={15} />
          </button>
        </div>
        {students.map((s) => (
          <div className="student-admin-row" key={s.id}>
            <div className="avatar">
              {s.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </div>
            <div>
              <b>{s.name}</b>
              <small>{s.id} · B.Tech</small>
            </div>
            <span className={`identity-status ${s.active ? "active" : "revoked"}`}>
              <span /> {s.active ? "Active" : "Revoked"}
            </span>
            <button
              className={s.active ? "revoke-button" : "restore-button"}
              onClick={() => toggle(s.id)}
            >
              {s.active ? "Revoke ID" : "Restore ID"}
            </button>
          </div>
        ))}
      </section>
    </main>
  );
}

function PlaceholderAdmin({ section }: { section: string }) {
  return (
    <main className="admin-page">
      <div className="admin-welcome">
        <div>
          <span>SECURITY OPERATIONS</span>
          <h2>{section}</h2>
          <p>Review and manage {section.toLowerCase()} across the identity platform.</p>
        </div>
      </div>
      <section className="dashboard-card placeholder-admin">
        <IconBubble
          icon={section === "Alerts" ? AlertTriangle : section === "Audit log" ? History : Settings}
          color="#2563eb"
          tint="#eff6ff"
          size={58}
        />
        <h3>{section} center</h3>
        <p>
          This interactive prototype includes a representative {section.toLowerCase()} view. Live
          data would appear here in production.
        </p>
        {section === "Audit log" && <LogTable />}
      </section>
    </main>
  );
}

export default function App() {
  const [page, setPage] = useState<Page>("landing");
  const [toast, setToast] = useState("");
  function navigate(next: Page) {
    setPage(next);
    window.scrollTo(0, 0);
  }
  function authenticated(role: Role) {
    setToast(`Signed in securely as ${role}`);
    window.setTimeout(() => setToast(""), 3000);
    navigate(role === "Student" ? "id" : role === "Staff" ? "verifier" : "admin");
  }
  return (
    <>
      {page === "landing" && <Landing navigate={navigate} />}
      {page === "login" && <Login navigate={navigate} onAuthenticated={authenticated} />}
      {page === "id" && <StudentId navigate={navigate} />}
      {page === "activity" && <StudentActivity navigate={navigate} />}
      {page === "verifier" && <Verifier navigate={navigate} />}
      {page === "admin" && <Admin navigate={navigate} />}
      {toast && (
        <div className="toast">
          <CheckCircle2 size={18} /> {toast}
        </div>
      )}
    </>
  );
}
